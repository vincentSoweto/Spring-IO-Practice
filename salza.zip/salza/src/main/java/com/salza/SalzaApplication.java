package com.salza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalzaApplication.class, args);
	}

}
